package com.danielveiga.horas;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.*;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.text.TextPosition;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> uploadCallback;
    private Uri selectedPdfUri;
    private static final int FILE_PICKER = 1001;
    private static final int MIC_PERMISSION = 1002;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        PDFBoxResourceLoader.init(getApplicationContext());
        webView = new WebView(this);
        webView.setLayoutParams(new ViewGroup.LayoutParams(-1,-1));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){
                if(uploadCallback!=null) uploadCallback.onReceiveValue(null);
                uploadCallback=cb;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/pdf");
                try { i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); } catch(Exception ignored) {}
                startActivityForResult(i,FILE_PICKER);
                return true;
            }
            @Override public void onPermissionRequest(PermissionRequest request){ runOnUiThread(() -> request.grant(request.getResources())); }
        });
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC_PERMISSION);
    }

    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(req==FILE_PICKER){
            Uri uri=(res==Activity.RESULT_OK&&data!=null)?data.getData():null;
            if(uri!=null){
                selectedPdfUri=uri;
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
            }
            Uri[] r=uri!=null?new Uri[]{uri}:null;
            if(uploadCallback!=null){uploadCallback.onReceiveValue(r);uploadCallback=null;}
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public void parsePlanning(final String employee){
            final Uri uri=selectedPdfUri;
            if(uri==null){
                runOnUiThread(() -> webView.evaluateJavascript("window.onNativePlanParsedError('Nenhum PDF selecionado')", null));
                return;
            }
            new Thread(() -> {
                try {
                    JSONArray result = parsePdf(uri, employee);
                    String json = result.toString().replace("\\", "\\\\").replace("'", "\\'");
                    runOnUiThread(() -> webView.evaluateJavascript("window.onNativePlanParsed('"+json+"')", null));
                } catch(Exception e){
                    String msg = e.getMessage()==null?e.toString():e.getMessage();
                    msg = msg.replace("\\","\\\\").replace("'","\\'").replace("\n"," ");
                    runOnUiThread(() -> webView.evaluateJavascript("window.onNativePlanParsedError('"+msg+"')", null));
                }
            }).start();
        }

        @JavascriptInterface public void printFinal(){
            runOnUiThread(() -> {
                try {
                    PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                    String job="Registo de Horas Colaborador - Daniel Veiga";
                    PrintAttributes attrs=new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build();
                    pm.print(job, webView.createPrintDocumentAdapter(job), attrs);
                } catch(Exception e){ webView.evaluateJavascript("alert('Não foi possível abrir a impressão: '+"+JSONObject.quote(e.getMessage())+")", null); }
            });
        }
    }

    private static class Word { String text; float x,y; Word(String t,float xx,float yy){text=t;x=xx;y=yy;} }
    private static class Line { float y,x; String text; List<Word> words=new ArrayList<>(); Line(float yy){y=yy;} }

    private static class CoordinateStripper extends PDFTextStripper {
        final List<Word> words=new ArrayList<>();
        CoordinateStripper() throws Exception { super(); setSortByPosition(true); }
        @Override protected void writeString(String string, List<TextPosition> positions) {
            StringBuilder cur=new StringBuilder(); float sx=0,sy=0,lastX=0;
            for(TextPosition tp:positions){
                String u=tp.getUnicode();
                if(u==null) continue;
                for(int i=0;i<u.length();i++){
                    char ch=u.charAt(i);
                    float x=tp.getXDirAdj() + (i * tp.getWidthDirAdj()/Math.max(1,u.length()));
                    float y=tp.getYDirAdj();
                    if(Character.isWhitespace(ch)){
                        if(cur.length()>0){ words.add(new Word(cur.toString(),sx,sy)); cur.setLength(0); }
                    } else {
                        if(cur.length()==0){ sx=x; sy=y; }
                        cur.append(ch); lastX=x;
                    }
                }
            }
            if(cur.length()>0) words.add(new Word(cur.toString(),sx,sy));
        }
    }

    private JSONArray parsePdf(Uri uri, String employee) throws Exception {
        String emp=norm(employee==null||employee.trim().isEmpty()?"Daniel Veiga":employee);
        JSONArray out=new JSONArray();
        InputStream in=getContentResolver().openInputStream(uri);
        if(in==null) throw new Exception("Não foi possível abrir o PDF");
        PDDocument doc=PDDocument.load(in);
        try {
            for(int pageIndex=0;pageIndex<doc.getNumberOfPages();pageIndex++){
                String weekStart = findWeekStart(doc, pageIndex);
                CoordinateStripper stripper=new CoordinateStripper();
                stripper.setStartPage(pageIndex+1); stripper.setEndPage(pageIndex+1); stripper.getText(doc);
                List<Word> words=stripper.words;
                for(int day=0;day<5;day++){
                    float lo=day*228f, hi=(day+1)*228f;
                    List<Word> col=new ArrayList<>();
                    for(Word w:words) if(w.x>=lo && w.x<hi+8) col.add(w);
                    List<Line> lines=makeLines(col);
                    List<Line> empLines=new ArrayList<>();
                    for(Line l:lines) if(norm(l.text).contains(emp)) empLines.add(l);
                    List<Line> codeLines=new ArrayList<>();
                    for(Line l:lines){ if(findWork(l.text)!=null) codeLines.add(l); }
                    for(Line eLine:empLines){
                        Line code=null; float best=999f;
                        for(Line c:codeLines){ float d=Math.abs(c.y-eLine.y); if(d<=40 && d<best){best=d;code=c;} }
                        if(code==null) continue;
                        String work=findWork(code.text); if(work==null) continue;
                        JSONObject obj=extractRecord(day,work,eLine,code,lines,lo,hi);
                        obj.put("page",pageIndex+1);
                        if(weekStart!=null) obj.put("date", addDays(weekStart, day));
                        out.put(obj);
                    }
                }
            }
        } finally { try{doc.close();}catch(Exception ignored){} try{in.close();}catch(Exception ignored){} }

        // deduplicate by day + work, keeping the richest record.
        LinkedHashMap<String,JSONObject> unique=new LinkedHashMap<>();
        for(int i=0;i<out.length();i++){
            JSONObject o=out.getJSONObject(i); String k=o.getInt("day")+"|"+norm(o.getString("work"));
            if(!unique.containsKey(k)) unique.put(k,o); else {
                JSONObject old=unique.get(k);
                String[] fields={"client","location","team","coord","vehicle"};
                for(String f:fields) if(old.optString(f,"").isEmpty()&&!o.optString(f,"").isEmpty()) old.put(f,o.getString(f));
            }
        }
        JSONArray result=new JSONArray(); for(JSONObject o:unique.values()) result.put(o); return result;
    }

    private String findWeekStart(PDDocument doc,int pageIndex) throws Exception {
        PDFTextStripper s=new PDFTextStripper(); s.setStartPage(pageIndex+1); s.setEndPage(pageIndex+1); s.setSortByPosition(true);
        String text=s.getText(doc);
        Matcher m=Pattern.compile("(?i)Semana\\s+\\d+\\s*-\\s*(\\d{1,2})\\s+de\\s+([A-Za-zÀ-ÿ]+).*?(\\d{4})").matcher(text);
        if(!m.find()) return null;
        int day=Integer.parseInt(m.group(1)); int year=Integer.parseInt(m.group(3)); int month=monthNumber(m.group(2));
        if(month<1) return null;
        return String.format(Locale.US,"%04d-%02d-%02d",year,month,day);
    }
    private int monthNumber(String m){
        String x=norm(m); String[] names={"janeiro","fevereiro","marco","abril","maio","junho","julho","agosto","setembro","outubro","novembro","dezembro"};
        for(int i=0;i<names.length;i++) if(x.equals(names[i])||x.replace("ç","c").equals(names[i])) return i+1; return -1;
    }
    private String addDays(String iso,int days){
        try{String[] p=iso.split("-");Calendar c=Calendar.getInstance();c.set(Integer.parseInt(p[0]),Integer.parseInt(p[1])-1,Integer.parseInt(p[2]),12,0,0);c.add(Calendar.DAY_OF_MONTH,days);return String.format(Locale.US,"%04d-%02d-%02d",c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH));}catch(Exception e){return iso;}
    }

    private JSONObject extractRecord(int day,String work,Line employeeLine,Line codeLine,List<Line> lines,float lo,float hi) throws Exception {
        JSONObject o=new JSONObject(); o.put("day",day);o.put("work",work);o.put("client","");o.put("location","");o.put("team","");o.put("coord","");o.put("vehicle","");
        float ey=employeeLine.y, cy=codeLine.y;
        // Team: names at the left side in the row immediately above/at employee.
        String team="";
        String[] employeeParts=employeeLine.text.split("\\s+");
        for(Line l:lines){
            if(l.y<ey-18||l.y>ey+2) continue;
            StringBuilder left=new StringBuilder();
            for(Word w:l.words){
                boolean isEmployee=false; for(String part:employeeParts) if(norm(part).equals(norm(w.text))) {isEmployee=true;break;}
                if(w.x<lo+120 && !norm(w.text).equals("1") && !isEmployee){
                    if(left.length()>0) left.append(' '); left.append(w.text);
                }
            }
            String t=cleanTeam(left.toString());
            if(!t.isEmpty()&&!norm(t).contains("daniel")){team=t;break;}
        }
        o.put("team",team);

        // Information on the right side of the day column.
        List<Line> info=new ArrayList<>();
        for(Line l:lines){ if(l.y>=cy-38 && l.y<=cy+16) info.add(l); }
        Collections.sort(info,Comparator.comparingDouble(a->a.y));
        String coord="", client="", location="";
        for(Line l:info){
            String t=lineTextInX(l,lo+118,hi+2).trim();
            if(t.isEmpty()) continue;
            String nt=norm(t);
            if(nt.startsWith("do -")){coord=t.replaceFirst("(?i)^DO\\s*-\\s*","").trim();continue;}
            if(t.matches("(?i)^(?:DZ|UI|HP|BA|ZX|AC)$")) continue;
            if(findWork(t)!=null) continue;
            float d=cy-l.y;
            if(d>13 && d<30 && client.isEmpty()) client=t;
            if(d>=5 && d<=12 && location.isEmpty()) location=t;
        }
        // If the locality is embedded in the client line (e.g. "Confraria Nazaré"), keep the full line as client and
        // use the last token as locality only when the line has no obvious description marker.
        if(location.isEmpty() && !client.isEmpty()){
            String[] p=client.split("\\s+");
            if(p.length>=2 && p[p.length-1].length()>=4) location=p[p.length-1];
        }
        o.put("client",client);o.put("location",location);o.put("coord",coord);
        // Vehicle: near the right edge of the fixed 228px day column, closest to employee row.
        String vehicle="";float bd=999;
        for(Word w:wordsAround(lines,hi-4,hi+8,ey-18,ey+18)){
            if(w.text.matches("(?i)^[A-Z]{2}$")){float d=Math.abs(w.y-ey);if(d<bd){bd=d;vehicle=w.text;}}
        }
        o.put("vehicle",vehicle);
        return o;
    }

    private String lineTextInX(Line l,float x1,float x2){
        StringBuilder sb=new StringBuilder();
        for(Word w:l.words) if(w.x>=x1&&w.x<x2){if(sb.length()>0)sb.append(' ');sb.append(w.text);}
        return sb.toString();
    }

    private List<Word> wordsAround(List<Line> lines,float x1,float x2,float y1,float y2){
        List<Word> r=new ArrayList<>();for(Line l:lines)for(Word w:l.words)if(w.x>=x1&&w.x<=x2&&w.y>=y1&&w.y<=y2)r.add(w);return r;
    }
    private static List<Line> makeLines(List<Word> words){
        List<Word> sorted=new ArrayList<>(words);Collections.sort(sorted,(a,b)->{int c=Float.compare(a.y,b.y);return c!=0?c:Float.compare(a.x,b.x);});
        List<Line> lines=new ArrayList<>();
        for(Word w:sorted){Line hit=null;for(Line l:lines){if(Math.abs(l.y-w.y)<=2.5f){hit=l;break;}}if(hit==null){hit=new Line(w.y);lines.add(hit);}hit.words.add(w);}
        for(Line l:lines){Collections.sort(l.words,Comparator.comparingDouble(a->a.x));StringBuilder sb=new StringBuilder();for(Word w:l.words){if(sb.length()>0)sb.append(' ');sb.append(w.text);if(l.x==0||w.x<l.x)l.x=w.x;}l.text=sb.toString().trim();}
        Collections.sort(lines,Comparator.comparingDouble(a->a.y));return lines;
    }
    private static String findWork(String t){
        Matcher m=Pattern.compile("(?i)\\b(\\d{2}-\\d{4})\\b").matcher(t);if(m.find())return m.group(1);
        m=Pattern.compile("(?i)\\bPAT\\s+(\\d+)\\b").matcher(t);if(m.find())return "PAT "+m.group(1);return null;
    }
    private static String cleanTeam(String t){
        String s=t.replaceAll("(?i)\\b1\\b","").replaceAll("\\s+"," ").trim();
        if(norm(s).startsWith("do -")) return ""; return s;
    }
    private static String norm(String s){return (s==null?"":s).toLowerCase(Locale.ROOT).replaceAll("\\s+"," ").trim();}

    @Override public void onBackPressed(){ if(webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
