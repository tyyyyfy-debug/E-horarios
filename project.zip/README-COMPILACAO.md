# Horas Daniel — compilação Android

## Correção desta versão
Esta versão não usa AppCompat nem dependências externas. O tema usa o tema Material nativo do Android para evitar o erro `Theme.AppCompat.DayNight.NoActionBar` / `Android resource linking failed`.

## Abrir no Android Studio
Abra esta pasta como projeto Gradle e aguarde o Gradle Sync.

## Gerar APK
Menu: Build → Build Bundle(s) / APK(s) → Build APK(s).

APK esperado:
`app/build/outputs/apk/debug/app-debug.apk`

Se o Android Studio pedir para atualizar o Gradle, não faça atualizações automáticas agora; use as versões do projeto.
